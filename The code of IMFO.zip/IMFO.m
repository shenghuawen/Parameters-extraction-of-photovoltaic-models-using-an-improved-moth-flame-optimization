%___________________________________________________________________%
%  Improved moth-flame optimization (IMFO) source codes version 1.0 %
%                                                                   %
%  Developed in MATLAB R2018b                                       %
%                                                                   %
%  Author and programmer: Huawen Sheng                              %
%                                                                   %
%         E-Mail: huawensheng@outlook.com                           %
%                                                                   %
%   Main paper: Parameters extraction of photovoltaic 
%               models using an improved moth-flame optimization    %
%___________________________________________________________________%
clear;
clc;
format long; 
addpath('Benchmark_Solar_Cell');  
fun = @evaluate_normal_fitness;
runs=30; % The runs of test on each PV model
func_flags=3; % The number of PV models
FE_jilu=cell(1,3); 
FE_jilu2=cell(1,3);
allgbestval_30=cell(1,runs);
algorithm = 'IMFO';
time=zeros(func_flags,runs);
for func_flag=1:func_flags
    fprintf('func_flag =\t %d\n',func_flag);
     PV_Xrange;
     num=100;  % Number of search agents
     dim=D;   % the number of the dimensions
     max_fes= 10000*D;   % Maximum numbef of fitness
     Max_iteration = max_fes/num;   % Maximum numbef of iterations
     allgbest_val = zeros(runs,1);
     allgbest = zeros(runs,dim);
     allgbestval_30=zeros(runs,Max_iteration);
     for run=1:runs
         rand('state',sum(100*clock));
         fprintf('run =\t %d\n',run);
tic  
M=4;  % The number of the sub-swarms
N=25; % The number of moths in each sub-swarm
allgbestval=zeros(1,Max_iteration);
fitcount=0;
Iteration=1;
lbest_pos=zeros(M,dim);
lbest_val=zeros(1,M);
Moth_fitness=zeros(1,num);
Moth_pos=repmat(Xmin, num, 1) + rand(num, D) .* (repmat(Xmax-Xmin, num, 1)); %Initialize the positions of moths

for i=1:num
    Moth_fitness(i)=fun(Moth_pos(i,:),func_flag); % Calculate the fitnesses of the moths
    fitcount=fitcount+1;
end
for j=1:M  % Divide the single moths swarm into M sub-swarms
     Moth_fitness1=Moth_fitness(((j-1)*N+1):N*j);
     [lbest_val(j),l_index]=min(Moth_fitness1);
     lbest_pos(j,:)=Moth_pos(l_index+(j-1)*N,:); 
end
pbest_pos=Moth_pos;
pbest_val=Moth_fitness;
[gbestval,index]=min(Moth_fitness);
gbest=Moth_pos(index,:);
allgbestval(Iteration)=gbestval;
%   Main loop
while Iteration<=Max_iteration&& fitcount<=max_fes
   Iteration=Iteration+1;
    a=-1+Iteration*((-1)/Max_iteration);
    for i=1:num
        P=0.4; % The reasonable probability of selection
           if rand()>P   %  if ?>P�� The update strategy (17) is selected
                distance_to_flame=abs(lbest_pos(ceil(i/N),:)-Moth_pos(i,:));
                b=1;
                t=(a-1).*rand()+1;
                Moth_pos(i,:)=distance_to_flame.*exp(b.*t).*cos(t.*2*pi)+lbest_pos(ceil(i/N),:);  
           else  %  if ?<=P�� The update strategy (18) is selected
                distance_to_flame=abs(sum(pbest_pos)/num-Moth_pos(i,:));
                b=1;
                t=(a-1).*rand()+1; 
                Moth_pos(i,:)=distance_to_flame.*exp(b.*t).*cos(t.*2*pi)+sum(pbest_pos)/num;
           end
           Moth_pos(i,:) = boundConstraint_absorb(Moth_pos(i,:), Xmin, Xmax); % Boundary processing of each updated moths
           Moth_fitness(i)=fun(Moth_pos(i,:),func_flag);  %  Calculate the fitness of each updated moths
           fitcount=fitcount+1;
           if  Moth_fitness(i)<pbest_val(i)       % Update pbest value and position
               pbest_pos(i,:)=Moth_pos(i,:);   
               pbest_val(i)=Moth_fitness(i);
           end
          
           if  pbest_val(i)<lbest_val(ceil(i/N))   % Update LF value and postion
               lbest_pos(ceil(i/N),:)=pbest_pos(i,:); 
               lbest_val(ceil(i/N))=pbest_val(i);
           end 
           
           if  pbest_val(i)<gbestval              % Update GF value and position
               gbest=Moth_pos(i,:);   
               gbestval=Moth_fitness(i);
           end
    end
        allgbestval(Iteration)=gbestval;
        if fitcount>=max_fes
            break;
        end 
        if (Iteration==Max_iteration)&&(fitcount<max_fes)
            Iteration=Iteration-1;
        end       
        
end
allgbest_val(run)=gbestval;
allgbest(run,:)=gbest;
toc
time(func_flag,run)=toc;
     end
FE_jilu{1,func_flag}=allgbest_val;
FE_jilu2{1,func_flag}=allgbest;
E_mean(func_flag)=mean( allgbest_val,1);% The mean value of the 30 runs' error
E_stdv(func_flag)=std( allgbest_val,0); % The standard deviation value of the 30 runs' error
end
 fprintf('run func_flag end=\t %d\n',func_flag);
 file_name= [ 'IMFO_2019_6_8_Test',num2str(01),'_30runs.mat'];
 save (file_name);

